package se.kth.id2212.ex1.compute;

import java.io.Serializable;

public interface Task extends Serializable
{
    public void execute();
}
